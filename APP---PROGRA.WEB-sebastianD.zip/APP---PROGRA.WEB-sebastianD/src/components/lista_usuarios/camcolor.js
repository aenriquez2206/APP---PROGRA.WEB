
export function estadoClase(estado) {
  return estado == "Activo" ? "estado_verde" : "estado_rojo";
}

