
export function estadoClase(estado) {
  return estado == "Entregado" ? "estado_verde" : "estado_rojo";
}