import Header from "../components/header/Header"
import NavBar from "../components/navBar/NavBar"

const DashboardAdmin =() =>{
    return(<>

    </>)
}


export default DashboardAdmin